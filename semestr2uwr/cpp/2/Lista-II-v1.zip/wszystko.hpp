#ifndef WSZYSTKO_HPP
#define WSZYSTKO_HPP
#include <cmath>
#include <algorithm>
#include <iostream>
using namespace std;

const double pi = 3.1415926535897932386426433832795;

class wektor {
    private:
        double a, b;
    public:
        wektor();
        wektor(double x, double y);
        double wsp_a ();
        double wsp_b ();
};

class prosta {
    private:
        double m;
        double n;
        double l;
    public:
        prosta();
        prosta(double x, double y, double z);
        double wez_m();
        double wez_n();
        double wez_l();
};

class punkt {
    private:
        double x, y;
    public:
        punkt();
        punkt(double a, double b);
        ~punkt();
        punkt& operator=(const punkt& a);
        punkt(const punkt &t);
        double wsp_x ();
        double wsp_y ();
        void translacja(wektor a);
        void obrot (double alpha, punkt b);
        void sym_punkt(punkt b);
        void sym_os_x();
        void sym_os_y();
};

double odleglosc (punkt &p, punkt &r);

class odcinek {
    private:
        punkt i;
        punkt j;
    public:
        odcinek (punkt a, punkt b); 
        odcinek(const odcinek &t);
        odcinek& operator=(const odcinek& a);
        punkt wez_punkt_i();
        punkt wez_punkt_j();
        void translacja(wektor a);
        void obrot (double alpha, punkt b);
        void sym_punkt(punkt b);
        void sym_os_x();
        void sym_os_y();
        double dlugosc();
        bool nalezy(punkt a);
};

double strona (punkt a, punkt b, punkt c);
bool rownolegle(odcinek a, odcinek b);
bool prostopadle(odcinek a, odcinek b);

class trojkat
{
    private:
        punkt d;
        punkt e;
        punkt f;
    public:
        trojkat(punkt a, punkt b, punkt c);
        trojkat(const trojkat &t);
        trojkat& operator=(const trojkat& a);
        punkt wez_punkt_d ();
        punkt wez_punkt_e ();
        punkt wez_punkt_f ();
        void translacja(wektor a);
        void obrot (double alpha, punkt b);
        void sym_punkt(punkt b);
        void sym_os_x();
        void sym_os_y();
        double obwod();
        double pole();
        bool nalezy(punkt c);
};

bool rozlaczne(trojkat a, trojkat b);
bool zawiera(trojkat a, trojkat b);

#endif