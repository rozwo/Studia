#include "trojkat.hpp"

double odleglosc(punkt &p, punkt &r);

double strona(punkt a, punkt b, punkt c);
bool rownolegle(odcinek a, odcinek b);
bool prostopadle(odcinek a, odcinek b);

bool rozlaczne(trojkat a, trojkat b);
bool zawiera(trojkat a, trojkat b);
