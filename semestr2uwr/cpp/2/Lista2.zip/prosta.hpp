#include "wektor.hpp"

class prosta {
    private:
        double m;
        double n;
        double l;
    public:
        prosta();
        prosta(double x, double y, double z);
        double wez_m();
        double wez_n();
        double wez_l();
};
